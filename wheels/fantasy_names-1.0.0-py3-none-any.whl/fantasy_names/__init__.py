from .armor_names import make_name as armor_name
from .weapon_names import make_name as weapon_name
